window.__require = function e(t, o, n) {
function s(i, c) {
if (!o[i]) {
if (!t[i]) {
var r = i.split("/");
r = r[r.length - 1];
if (!t[r]) {
var l = "function" == typeof __require && __require;
if (!c && l) return l(r, !0);
if (a) return a(r, !0);
throw new Error("Cannot find module '" + i + "'");
}
}
var d = o[i] = {
exports: {}
};
t[i][0].call(d.exports, function(e) {
return s(t[i][1][e] || e);
}, d, d.exports, e, t, o, n);
}
return o[i].exports;
}
for (var a = "function" == typeof __require && __require, i = 0; i < n.length; i++) s(n[i]);
return s;
}({
AdsManagerHall: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "c4abdc7jC1HNIhsPQ8fkw2u", "AdsManagerHall");
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = cc._decorator;
n.ccclass, n.property;
(function(e) {
e[e.kTypeNativeAds = 32] = "kTypeNativeAds";
e[e.kTypeRectAds = 16] = "kTypeRectAds";
e[e.kTypeBannerAds = 8] = "kTypeBannerAds";
e[e.kTypeInterstitialAds = 4] = "kTypeInterstitialAds";
e[e.kTypeCrosspromoAds = 2] = "kTypeCrosspromoAds";
e[e.kTypeRewardedAds = 1] = "kTypeRewardedAds";
})(o.ADS_TYPE || (o.ADS_TYPE = {}));
var s = function() {
function e() {
this.initLisenter();
}
e.getInstance = function() {
null == e._instance && (e._instance = new e());
return e._instance;
};
e.prototype.initLisenter = function() {
var e = jsToCPP.getInstance();
e.initOnAdsLoaded(function(e) {
console.log(" 广告加载====>ID值" + e);
console.log(this.onAdsLoaded);
this.onAdsLoaded && this.onAdsLoaded(e);
}.bind(this));
e.initOnAdsClicked(function(e) {
console.log(" 广告点击====>ID值" + e);
this.onAdsClicked && this.onAdsClicked(e);
}.bind(this));
e.initOnAdsExpanded(function(e) {
console.log(" 广告====>ID值" + e);
this.onAdsExpanded && this.onAdsExpanded(e);
}.bind(this));
e.initOnAdsCollapsed(function(e) {
console.log(" 广告关闭====>ID值" + e);
this.onAdsCollapsed && this.onAdsCollapsed(e);
}.bind(this));
e.initOnAdsLoadFailed(function(e, t) {
console.log(" 广告加载失败====>ID值" + t + "名称" + e);
this.onAdsLoadFailed && this.onAdsLoadFailed(e, t);
}.bind(this));
e.initOnAdsRewarded(function(e, t, o) {
console.log(" reward广告====>ID值" + t + "名称" + e + "是否成功" + o);
this.onAdsRewarded && this.onAdsRewarded(e, t, o);
}.bind(this));
};
e.prototype.public = function() {
jsToCPP.getInstance().showInterstitial();
};
e.prototype.showInterstitial = function() {
return jsToCPP.getInstance().showInterstitial();
};
e.prototype.showCross = function() {
return jsToCPP.getInstance().showCross();
};
e.prototype.showBanner = function() {
jsToCPP.getInstance().showBanner();
};
e.prototype.hideBanner = function() {
jsToCPP.getInstance().hideBanner();
};
e.prototype.showReward = function() {
return jsToCPP.getInstance().showReward();
};
e.prototype.preAllAds = function() {
jsToCPP.getInstance().preLoadAllAds();
};
e.prototype.preAdsByType = function(e) {
jsToCPP.getInstance().preLoadAds(Number(e));
};
return e;
}();
o.default = s;
cc._RF.pop();
}, {} ],
BgScale_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "8f7c9ns7htM1arvXBxakfAL", "BgScale_my");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = a.disallowMultiple, r = a.menu, l = function(e) {
n(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.setBgScale = function() {
if (this.enabled) {
var e = cc.view.getVisibleSize(), t = this.node.width, o = this.node.height;
o < e.height && this.node.setScale(e.height / o);
t < e.width && this.node.setScale(e.width / t);
}
};
t.prototype.onEnable = function() {
this.setBgScale();
};
t.prototype.onLoad = function() {
var e = this;
this.setBgScale();
null == this.rf && (this.rf = cc.director.on("ResizeFrame", function() {
e.setBgScale();
}, this));
};
t.prototype.onDestroy = function() {
null != this.rf && cc.director.off("ResizeFrame", this.rf, this);
};
return t = s([ i, c(), r("common/viewadapter/BgScale") ], t);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
ButtonSafe_hall: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "9282bW6Y1NBJq52TqPOhzE7", "ButtonSafe_hall");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = a.property, r = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.safeTime = .5;
t.clickEvents = [];
return t;
}
t.prototype.start = function() {
var e = this, t = this.node.getComponent(cc.Button);
if (t) {
this.clickEvents = t.clickEvents;
var o = this, n = !1;
this.node.on("click", function() {
t.clickEvents = [];
if (!n) {
n = !0;
o.scheduleOnce(function(e) {
t.clickEvents = o.clickEvents;
n = !1;
}, e.safeTime);
}
}, this);
}
};
s([ c ], t.prototype, "safeTime", void 0);
return t = s([ i ], t);
}(cc.Component);
o.default = r;
cc._RF.pop();
}, {} ],
ClickScale_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "c508fdYYRVPJrO5AB44iR9E", "ClickScale_my");
cc.Class({
extends: cc.Component,
properties: {},
onLoad: function() {
this.node.on(cc.Node.EventType.TOUCH_START, function() {
var e = cc.scaleTo(.156, 1, .8);
this.node.runAction(e);
}, this);
var e = function() {
var e = cc.scaleTo(.132, .82, 1), t = cc.scaleTo(.12, 1, .86), o = cc.scaleTo(.108, .88, 1), n = cc.scaleTo(.096, 1, .89), s = cc.scaleTo(.084, 1), a = cc.sequence(e, t, o, n, s);
this.node.runAction(a);
};
this.node.on(cc.Node.EventType.TOUCH_END, e, this);
this.node.on(cc.Node.EventType.TOUCH_CANCEL, e, this);
}
});
cc._RF.pop();
}, {} ],
CocosHelper_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "fd8abSdoZNI8rh0m5qjlA+M", "CocosHelper_my");
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = function() {
function e() {}
e.findNode_if = function(e, t) {
cc.ParticleSystem;
var o = null;
if (null != e) {
if (t(e)) o = e; else for (var n = 0, s = e.children; n < s.length; n++) {
var a = s[n];
if (null != (o = this.findNode_if(a, t))) break;
}
}
return o;
};
e.showHand = function(e, t, o, n) {
var s = e.parent.convertToNodeSpaceAR(t.convertToWorldSpaceAR(cc.v2(0, 0))), a = e.parent.convertToNodeSpaceAR(o.convertToWorldSpaceAR(cc.v2(0, 0))), i = e.parent.convertToNodeSpaceAR(n.convertToWorldSpaceAR(cc.v2(0, 0)));
if (t.name == o.name) {
var c = cc.moveTo(1, a), r = cc.moveTo(1, i);
e.runAction(cc.repeatForever(cc.sequence(cc.callFunc(function() {
e.setPosition(s);
}), r, cc.callFunc(function() {
e.setPosition(cc.v2(1e3, 1e6));
}), cc.delayTime(1))));
} else {
c = cc.moveTo(1, a), r = cc.moveTo(1, i);
e.runAction(cc.repeatForever(cc.sequence(cc.callFunc(function() {
e.setPosition(s);
}), c, r, cc.callFunc(function() {
e.setPosition(cc.v2(1e3, 1e6));
}), cc.delayTime(1))));
}
};
e.findNode = function(t, o) {
void 0 === t && (t = cc.director.getScene());
return e.findNode_if(t, function(e) {
return e.name == o;
});
};
e.visitNode = function(t, o) {
e.findNode_if(t, function(e) {
o(e);
return !1;
});
};
e.creatrScale = function(e) {
e.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(1.5, 1.05), cc.scaleTo(1.5, 1))));
};
e.rotate = function(e) {
e.runAction(cc.repeatForever(cc.sequence(cc.rotateTo(1.5, 6), cc.rotateTo(1.5, -6))));
};
e.getScreenPos = function(t, o) {
var n, s = cc.Camera.findCamera(t), a = cc.view.getDesignResolutionSize(), i = new cc.Vec2(0, a.height), c = new cc.Vec2(a.width, 0), r = t.position;
t.position;
null != t.parent && (r = t.parent.convertToWorldSpaceAR(r));
if (null != s) {
i = s.getCameraToWorldPoint(i, new cc.Vec2());
c = s.getCameraToWorldPoint(c, new cc.Vec2());
}
switch (o) {
case e.ShowDirection.show_from_bottom:
n = new cc.Vec2(r.x, c.y - t.getContentSize().height * (1 - t.getAnchorPoint().y));
break;

case e.ShowDirection.show_from_left:
n = new cc.Vec2(i.x - t.getContentSize().width * (1 - t.getAnchorPoint().x), r.y);
break;

case e.ShowDirection.show_from_right:
n = new cc.Vec2(c.x + t.getContentSize().width * t.getAnchorPoint().x, r.y);
break;

case e.ShowDirection.show_from_top:
n = new cc.Vec2(r.x, i.y + t.getContentSize().width * t.getAnchorPoint().y);
}
null != t.parent && (n = t.parent.convertToNodeSpaceAR(n));
return n;
};
e.hideNode = function(t, o, n, s, a) {
void 0 === n && (n = null);
void 0 === s && (s = !0);
void 0 === a && (a = .6);
var i = e.getScreenPos(t, o), c = new cc.Tween();
c.to(a, {
position: i
}, {
progress: null,
easing: "expoIn"
});
null != n && c.call(n);
s ? c.removeSelf() : c.call(function() {
t.active = !1;
});
c.target(t).start();
};
e.showBackOut = function(t, o, n, s) {
void 0 === n && (n = null);
void 0 === s && (s = 1);
t.active = !0;
var a = t.position, i = e.getScreenPos(t, o);
t.setPosition(i);
var c = new cc.Tween();
c.to(s, {
position: a
}, {
progress: null,
easing: "backOut"
});
null != n && c.call(n);
c.target(t).start();
};
e.captureNode = function(e) {
return new Promise(function(t, o) {
var n = Math.floor(e.width), s = Math.floor(e.height), a = e.getChildByName("cameraNode");
if (!a) {
(a = new cc.Node("cameraNode")).parent = e;
a.x = 0;
a.y = 0;
}
var i = a.getComponent(cc.Camera);
i || (i = a.addComponent(cc.Camera));
var c = e.group;
e.group = "captureLayer";
i.cullingMask = e._cullingMask;
var r = new cc.RenderTexture();
r.initWithSize(n, s, cc.game._renderContext.STENCIL_INDEX8);
i.targetTexture = r;
var l = e.scaleY;
e.scaleY = -1 * l;
i.render(null);
e.scaleY = l;
e.group = c;
t(r);
});
};
e.captureNode2 = function(e) {
var t = Math.floor(e.width), o = Math.floor(e.height), n = e.getChildByName("cameraNode");
if (!n) {
(n = new cc.Node("cameraNode")).parent = e;
n.x = 0;
n.y = 0;
}
var s = n.getComponent(cc.Camera);
s || (s = n.addComponent(cc.Camera));
var a = e.group;
e.group = "captureLayer";
s.cullingMask = e._cullingMask;
var i = new cc.RenderTexture();
i.initWithSize(t, o, cc.game._renderContext.STENCIL_INDEX8);
s.targetTexture = i;
var c = e.scaleY;
e.scaleY = -1 * c;
s.render(null);
e.scaleY = c;
e.group = a;
return i;
};
e.captureNodeSize = function(e, t, o) {
return new Promise(function(n, s) {
var a = e.getChildByName("cameraNode");
if (!a) {
(a = new cc.Node("cameraNode")).parent = e;
a.x = 0;
a.y = 0;
}
var i = a.getComponent(cc.Camera);
i || (i = a.addComponent(cc.Camera));
var c = e.group;
e.group = "captureLayer";
i.cullingMask = e._cullingMask;
var r = new cc.RenderTexture();
r.initWithSize(t, o, cc.game._renderContext.STENCIL_INDEX8);
i.targetTexture = r;
var l = e.scaleY;
e.scaleY = -1 * l;
i.render(null);
i.enabled = !1;
e.scaleY = l;
e.group = c;
n(r);
});
};
e.saveToAlbum = function(t) {
e.captureNode(cc.Canvas.instance.node).then(function(e) {
if (null == e) t(!1); else {
var o = e.readPixels(), n = e.width, s = e.height, a = Date.parse(new Date().toString()), i = jsb.fileUtils.getWritablePath() + a + ".png";
jsb.saveImageData(o, n, s, i) ? jsToCPP.getInstance().doRuntimePermission(i, 1, function(e) {
console.log("保存相册回调 " + e);
}) : t(!1);
}
});
};
e.filpYImage = function(e, t, o) {
for (var n = new Uint8Array(t * o * 4), s = 4 * t, a = 0; a < o; a++) for (var i = (o - 1 - a) * t * 4, c = a * t * 4, r = 0; r < s; r++) n[c + r] = e[i + r];
return n;
};
e.createAnimation = function(e, t, o) {
for (var n = [], s = function(t) {
n.push(cc.callFunc(function() {
e.spriteFrame = t;
}));
n.push(cc.delayTime(o));
}, a = 0, i = t; a < i.length; a++) {
s(i[a]);
}
return cc.sequence(n);
};
return e;
}();
o.CocosHelper = n;
(function(e) {
(function(e) {
e[e.show_from_top = 0] = "show_from_top";
e[e.show_from_bottom = 1] = "show_from_bottom";
e[e.show_from_left = 2] = "show_from_left";
e[e.show_from_right = 3] = "show_from_right";
})(e.ShowDirection || (e.ShowDirection = {}));
})(n = o.CocosHelper || (o.CocosHelper = {}));
o.CocosHelper = n;
cc._RF.pop();
}, {} ],
ColorRectAssembler_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e2b85ecOkxOuKopv0MpofAP", "ColorRectAssembler_my");
t.exports = {
useModel: !1,
updateRenderData: function(e) {
if (!e._renderData) {
var t = cc.IARenderData;
e._renderData = new t();
e._renderData.material = e.getMaterial();
e._renderData.ia = e._ia;
}
},
renderIA: function(e, t) {
t._flushIA(e._renderData);
}
};
cc._RF.pop();
}, {} ],
ColorRect_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "828e5zeeN1D57k8RVvANCys", "ColorRect_my");
var n = e("./ColorRectAssembler_my"), s = void 0, a = void 0, i = void 0, c = void 0, r = void 0;
cc.game.once(cc.game.EVENT_ENGINE_INITED, function() {
s = cc.renderer.renderEngine;
a = cc.gfx;
i = cc.vmath;
c = i.mat4.create();
r = i.mat4.create();
});
var l = cc.Class({
extends: cc.RenderComponent,
properties: {
blColor: cc.Color,
brColor: cc.Color,
tlColor: cc.Color,
trColor: cc.Color
},
_updateVertexData: function(e) {
var t = this._vData, o = this._uintVData, n = this.node.width, s = this.node.height, a = n * this.node.anchorX, i = s * this.node.anchorY, c = e.m00, r = e.m01, l = e.m04, d = e.m05, h = e.m12, u = e.m13, p = void 0, f = void 0, g = 0, _ = this.node.opacity;
this.blColor.a = _;
this.brColor.a = _;
this.tlColor.a = _;
this.trColor.a = _;
p = -a;
f = -i;
t[g++] = p * c + f * l + h;
t[g++] = p * r + f * d + u;
o[g++] = this.blColor._val;
p = n - a;
f = -i;
t[g++] = p * c + f * l + h;
t[g++] = p * r + f * d + u;
o[g++] = this.brColor._val;
p = -a;
f = s - i;
t[g++] = p * c + f * l + h;
t[g++] = p * r + f * d + u;
o[g++] = this.tlColor._val;
p = n - a;
f = s - i;
t[g++] = p * c + f * l + h;
t[g++] = p * r + f * d + u;
o[g++] = this.trColor._val;
this._vb.update(0, t);
},
_createIA: function() {
var e = cc.renderer.device;
this._vertexFormat = new a.VertexFormat([ {
name: a.ATTR_POSITION,
type: a.ATTR_TYPE_FLOAT32,
num: 2
}, {
name: a.ATTR_COLOR,
type: a.ATTR_TYPE_UINT8,
num: 4,
normalize: !0
} ]);
this._vData = new Float32Array(12);
this._uintVData = new Uint32Array(this._vData.buffer);
this._iData = new Uint16Array([ 0, 1, 2, 1, 3, 2 ]);
this._vb = new a.VertexBuffer(e, this._vertexFormat, a.USAGE_DYNAMIC, null, 4);
this._ib = new a.IndexBuffer(e, a.INDEX_FMT_UINT16, a.USAGE_STATIC, this._iData, this._iData.length);
this.node.getWorldMatrix(r);
this._updateVertexData(r);
this._ia = new s.InputAssembler();
this._ia._vertexBuffer = this._vb;
this._ia._indexBuffer = this._ib;
this._ia._start = 0;
this._ia._count = this._iData.length;
},
onEnable: function() {
this._super();
this.node._renderFlag &= ~cc.RenderFlow.FLAG_RENDER;
this.node._renderFlag |= cc.RenderFlow.FLAG_CUSTOM_IA_RENDER;
},
onLoad: function() {
this._material = new s.SpriteMaterial();
this._material.useTexture = !1;
this._material.useColor = !1;
this._createIA();
},
update: function() {
this.node.getWorldMatrix(r);
r.m00 === c.m00 && r.m01 === c.m01 && r.m04 === c.m04 && r.m05 === c.m05 && r.m12 === c.m12 && r.m13 === c.m13 || this._updateVertexData(r);
}
});
l._assembler = n;
t.exports = l;
cc._RF.pop();
}, {
"./ColorRectAssembler_my": "ColorRectAssembler_my"
} ],
GameData: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "f45cf4aS9BAPINZyb+33kij", "GameData");
var n = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var s = cc._decorator, a = s.ccclass, i = (s.property, e("./SubgameManager")), c = function() {
function e() {
this.mapGameDataItems = new Map();
this.touchCakeVector = [];
this.coinName = "coinhat";
this.selectGameName = "";
}
t = e;
e.getInstance = function() {
null == t._instance && (t._instance = new t());
return t._instance;
};
e.prototype.calCoinNum = function(e) {
var t = cc.sys.localStorage.getItem(this.coinName);
t || (t = 0);
var o = Number(t);
o += e;
cc.sys.localStorage.setItem(this.coinName, o);
};
e.prototype.setCoinNum = function(e) {
cc.sys.localStorage.setItem(this.coinName, e);
};
e.prototype.getStatusByName = function(e) {
var t = cc.sys.localStorage.getItem(e);
t || (t = "no");
return t;
};
e.prototype.setLightStatus = function(e) {
cc.sys.localStorage.setItem(e, "light");
};
e.prototype.setLightStatusUnLock = function(e) {
cc.sys.localStorage.setItem(e, "lightUnLock");
};
e.prototype.setTouchCakeVector = function() {
this.touchCakeVector = [];
for (var e = 2, t = 2; t < 11; t++) {
var o = "cake_" + t;
if (!this.getIsUpStoreByName(o)) break;
this.touchCakeVector.push(o);
e = t;
}
e < 11 && this.touchCakeVector.push("cake_" + e);
};
e.prototype.getTouchCakeVector = function() {
return this.touchCakeVector;
};
e.prototype.clearData = function() {
this.mapGameDataItems.clear();
};
e.prototype.getCoinNum = function() {
var e = cc.sys.localStorage.getItem(this.coinName);
e || (e = 0);
return e;
};
e.prototype.initData = function(e) {
var t = e.GameName, o = "new" == e.isNew, n = Number(e.Index), s = e.UpdateDate, a = "yes" == e.isUpStore, i = new r(t, o, n, s, a);
console.log(t + "--" + o + "--" + n + "---" + s);
this.mapGameDataItems.set(t, i);
};
e.prototype.getIndexFromName = function(e) {
var t = this.mapGameDataItems.get(e), o = 0;
t && (o = t.Index);
return o;
};
e.prototype.getIsUpStoreByName = function(e) {
var t = this.mapGameDataItems.get(e), o = !1;
t && (o = t.isUpStore);
return o;
};
e.prototype.getIsNewFromName = function(e) {
console.log("getIsNewFromName" + e);
var t = this.mapGameDataItems.get(e);
console.log("getIsNewFromName" + t);
var o = !1;
t && (o = t.isNew);
console.log("getIsNewFromName" + o);
i.isSubgameDownLoad(e) && (o = !1);
return o;
};
e.prototype.getDateFromName = function(e) {
var t = this.mapGameDataItems.get(e), o = "";
t && (o = t.UpdateDate);
return o;
};
e.prototype.getGameNameFormIndex = function(e) {
var t = this, o = "";
this.mapGameDataItems.forEach(function(n) {
console.log(n.Index + "---" + e);
if (n.Index == e) {
o = n.GameName;
console.log(o + "element.Index--\x3e" + e);
console.log(t.mapGameDataItems.get(o));
}
});
return o;
};
e.prototype.checkIsUpTo = function(e) {
return 0;
};
e.prototype.showPopAds = function(e, t) {
cc.loader.loadRes("popup_ads", cc.Prefab, function(e, t) {
e && console.log(e + "");
});
};
e.prototype.showPop = function(e) {
cc.loader.loadRes("pop_bg", cc.Prefab, function(t, o) {
if (t) console.log(t + ""); else {
var n = cc.instantiate(o);
n.parent = cc.Canvas.instance.node;
n.position = cc.v2(0, 0);
n.getChildByName("pop_bg_t").getChildByName("label").getComponent(cc.Label).string = e;
}
});
};
e.prototype.setSelectGameName = function(e) {
this.selectGameName = e;
cc.sys.localStorage.setItem("selectName", e);
};
e.prototype.getSelectGameName = function() {
this.selectGameName = cc.sys.localStorage.getItem("selectName");
return this.selectGameName;
};
var t;
return e = t = n([ a ], e);
}();
o.default = c;
var r = function() {
return function(e, t, o, n, s) {
this.GameName = e;
this.isNew = t;
this.UpdateDate = n;
this.Index = o;
this.isUpStore = s;
};
}();
cc._RF.pop();
}, {
"./SubgameManager": "SubgameManager"
} ],
HallDataConfig: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "20595AoR1BLhJFvWsx6lYcW", "HallDataConfig");
var n = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var s = cc._decorator, a = s.ccclass, i = (s.property, function() {
function e() {
this.ossName = "UnicornCakeHotUP/";
this.ossNameChina = "UnicornCakeHotUPChina/";
this.gameJson = "game.json";
this.versionJson = "version.json";
this.localAppName = "UnicornCakeHotUP/";
this.isInChaia = !1;
this.isDebug = !1;
this.getIsInChina();
this.init();
}
t = e;
e.getInstance = function() {
if (null == t._instance) {
t._instance = new t();
t._instance.init();
}
return t._instance;
};
e.prototype.init = function() {
console.log("初始化platformInstance");
window.platformInstance = t._instance;
};
e.prototype.getIsInChina = function() {
var e = "don not know", t = "don not know";
if (cc.sys.os == cc.sys.OS_IOS) {
console.log("cc.sys.OS_IOS");
e = jsb.reflection.callStaticMethod("AppController", "getLocaleLanguageCode");
t = jsb.reflection.callStaticMethod("AppController", "getCountryCode");
}
console.log("现在的国家语言" + e);
console.log("现在的国家" + t);
var o = String(t);
console.log(o.indexOf("zh"));
var n = !1, s = -1 != o.indexOf("zh");
console.log("是中国吗->" + s);
var a = -1 != o.indexOf("TW"), i = -1 != o.indexOf("HK");
if (s) {
if (a || i) {
n = !1;
console.log("处于中国台湾或者香港");
}
n = !0;
}
this.isInChaia = n;
};
e.prototype.getUrlBody = function() {
var e = "", t = this.ossName;
if (this.isInChaia) {
e = "https://unnicornfallcn.oss-cn-chengdu.aliyuncs.com/";
this.ossName = this.ossNameChina;
} else e = "http://youngcnfoodhall.top/";
cc.sys.os == cc.sys.OS_ANDROID && (this.ossName = t);
if (this.isDebug) {
e = "http://192.168.0.131:8000/";
this.ossName = t;
}
console.log("域名主体" + e);
console.log("服务器名称" + this.ossName);
return e;
};
e.prototype.getDownUrl = function() {
return this.getUrlBody() + this.ossName;
};
e.prototype.getGameJsonUrl = function() {
return this.getDownUrl() + this.gameJson;
};
e.prototype.getVersionJsonUrl = function() {
return this.getDownUrl() + this.versionJson;
};
e.prototype.getLocalAppName = function() {
return this.localAppName;
};
var t;
return e = t = n([ a ], e);
}());
o.default = i;
cc._RF.pop();
}, {} ],
Helloworld: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e1b90/rohdEk4SdmmEZANaD", "Helloworld");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = a.property, r = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.label = null;
t.text = "hello";
return t;
}
t.prototype.start = function() {
this.label.string = this.text;
};
s([ c(cc.Label) ], t.prototype, "label", void 0);
s([ c ], t.prototype, "text", void 0);
return t = s([ i ], t);
}(cc.Component);
o.default = r;
cc._RF.pop();
}, {} ],
HotUpdatePanel: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "f420awNPyZIGK5164SbpPge", "HotUpdatePanel");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = e("./HotUpdate"), i = cc._decorator, c = i.ccclass, r = i.property, l = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.pb = null;
t.manifestUrl = null;
t.popDialog = null;
t.label = null;
t.storagePath = null;
t.hotUpdate = null;
return t;
}
t.prototype._init = function() {
this.storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + "FoodHell";
this.hotUpdate = a.default.instance;
this.hotUpdate.init(this.manifestUrl, this.storagePath);
this._addUpdateListener();
};
t.prototype._addUpdateListener = function() {
this.hotUpdate.on("NEW_VERSION_FOUND", this._onNewVersionFound, this);
this.hotUpdate.on("ALREADY_UP_TO_DATE", this._onAlredyUpToDate, this);
this.hotUpdate.on("UPDATE_PROGRESSION", this._updataProgression, this);
this.hotUpdate.on("UPDATE_FAILED", this._onUpdateFailed, this);
this.hotUpdate.on("ERROR_NO_LOCAL_MANIFEST", this._onAlredyUpToDate, this);
this.hotUpdate.on("ERROR_DOWNLOAD_MANIFEST", this._onDownloadError, this);
this.hotUpdate.on("ERROR_PARSE_MANIFEST", this._onUpdateFailed, this);
this.hotUpdate.on("ERROR_DECOMPRESS", this._onUpdateFailed, this);
this.hotUpdate.on("ERROR_UPDATING", this._onUpdateFailed, this);
};
t.prototype._removeUpdateListener = function() {
this.hotUpdate.off("NEW_VERSION_FOUND", this._onNewVersionFound, this);
this.hotUpdate.off("ALREADY_UP_TO_DATE", this._onAlredyUpToDate, this);
this.hotUpdate.off("UPDATE_PROGRESSION", this._updataProgression, this);
this.hotUpdate.off("UPDATE_FAILED", this._onUpdateFailed, this);
this.hotUpdate.off("ERROR_NO_LOCAL_MANIFEST", this._onAlredyUpToDate, this);
this.hotUpdate.off("ERROR_DOWNLOAD_MANIFEST", this._onDownloadError, this);
this.hotUpdate.off("ERROR_PARSE_MANIFEST", this._onUpdateFailed, this);
this.hotUpdate.off("ERROR_DECOMPRESS", this._onUpdateFailed, this);
this.hotUpdate.off("ERROR_UPDATING", this._onUpdateFailed, this);
};
t.prototype._onNewVersionFound = function() {
this.node.active = !0;
console.log("is new");
this.popDialog.active = !0;
this.hotUpdate.execUpdate();
};
t.prototype._onAlredyUpToDate = function() {
window.allreadyUpdate = !0;
};
t.prototype._updataProgression = function(e) {
var t = e.progress;
if (t) {
var o = t.percent, n = t.filePercent, s = (t.downloadedFiles, t.totalFiles), a = t.downloadedBytes;
t.totalBytes;
this.pb.progress = o;
this.label.string = n + " " + o;
console.log(a + " " + s);
}
};
t.prototype._onDownloadError = function(e) {};
t.prototype._onUpdateFailed = function() {
this._retry(3);
};
t.prototype._retry = function(e) {
if (e > 0) {
this.hotUpdate.retry();
return this._retry(e - 1);
}
this._onDownloadError();
};
t.prototype.onLoad = function() {
if (window.allreadyUpdate) this.node.active = !1; else if (cc.sys.isNative) {
this._init();
this.hotUpdate.checkUpdate();
} else this._onAlredyUpToDate();
};
t.prototype.onDestroy = function() {
if (cc.sys.isNative && this.hotUpdate) {
this._removeUpdateListener();
this.hotUpdate.destroy();
}
};
s([ r(cc.ProgressBar) ], t.prototype, "pb", void 0);
s([ r({
type: cc.Asset
}) ], t.prototype, "manifestUrl", void 0);
s([ r({
type: cc.Node
}) ], t.prototype, "popDialog", void 0);
s([ r({
type: cc.Label
}) ], t.prototype, "label", void 0);
return t = s([ c ], t);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {
"./HotUpdate": "HotUpdate"
} ],
HotUpdate: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "e3ba3v9VB5OwrbqO4VbWxXi", "HotUpdate");
var n, s = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}();
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = function(e) {
s(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.manifestUrl = null;
t.stroagePath = "";
t.am = null;
t.updateListener = null;
t.updating = !1;
t.canRetry = !1;
return t;
}
Object.defineProperty(t, "instance", {
get: function() {
if (!cc.sys.isNative) throw new Error("Native only");
null == t._instance && (t._instance = new t());
return t._instance;
},
enumerable: !0,
configurable: !0
});
t.prototype.init = function(e, o) {
if (null == t.instance) throw new Error("not instance");
this._initAssetsManager(e, o);
};
t.prototype._initAssetsManager = function(e, t) {
this.stroagePath = t;
this.manifestUrl = e;
this.am = new jsb.AssetsManager(this.manifestUrl, t, this._versionCompareHandle);
this.am.setVerifyCallback(this._verifyCallback);
cc.sys.os == cc.sys.OS_ANDROID && this.am.setMaxConcurrentTask(3);
};
t.prototype._verifyCallback = function(e, t) {
t.compressed, t.md5, t.path, t.size;
return !0;
};
t.prototype._versionCompareHandle = function(e, t) {
for (var o = e.split("."), n = t.split("."), s = 0; s < o.length; ++s) {
var a = parseInt(o[s]), i = parseInt(n[s] || 0);
if (a != i) return a - i;
}
return n.length > o.length ? -1 : 0;
};
t.prototype.checkUpdate = function() {
console.log("1111");
if (this.updating) throw new Error("Checking or updating ...");
if (this.am.getState() == jsb.AssetsManager.State.UNINITED) {
var e = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (e = cc.loader.md5Pipe.transformURL(e));
this.am.loadLocalManifest(e);
}
if (!this.am.getLocalManifest() || !this.am.getLocalManifest().isLoaded()) throw new Error("Failed to load local manifest ...");
console.log("2222");
this.am.setEventCallback(this._checkCb.bind(this));
this.am.checkUpdate();
this.updating = !0;
};
t.prototype._checkCb = function(e) {
var o = 0, n = e.getEventCode(), s = t.EventType[n], a = "";
switch (n) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
a = e.getMessage();
break;

case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST");
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
o = e.getTotalBytes();
break;

default:
return;
}
this.am.setEventCallback(null);
this.updating = !1;
s && this.emit(s, {
totalBytes: o,
msg: a
});
};
t.prototype.execUpdate = function() {
if (this.am && !this.updating) {
this.am.setEventCallback(this._updateCb.bind(this));
if (this.am.getState() == jsb.AssetsManager.State.UNINITED) {
var e = this.manifestUrl.nativeUrl;
cc.loader.md5Pipe && (e = cc.loader.md5Pipe.transformURL(e));
this.am.loadLocalManifest(e);
}
this.am.update();
this.updating = !0;
}
};
t.prototype._updateCb = function(e) {
var o = !1, n = !1, s = e.getEventCode(), a = e.getMessage(), i = t.EventType[s], c = {
progress: null,
msg: a
};
switch (s) {
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
n = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var r = {
percent: Number.isNaN(e.getPercent()) ? 0 : e.getPercent(),
filePercent: e.getPercentByFile(),
downloadedFiles: e.getDownloadedFiles(),
totalFiles: e.getTotalFiles(),
downloadedBytes: e.getDownloadedBytes(),
totalBytes: e.getTotalBytes()
};
c.progress = r;
this.emit("UPDATE_PROGRESSION", c);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.updating = !1;
this.canRetry = !0;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
cc.error("asset", e.getAssetId(), a);
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
}
i && this.emit(i, c);
if (n) {
this.am.setEventCallback(null);
this.updateListener = null;
this.updating = !1;
}
if (o) {
this.am.setEventCallback(null);
this.updateListener = null;
var l = jsb.fileUtils.getSearchPaths(), d = this.am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(l, d);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(l));
jsb.fileUtils.setSearchPaths(l);
cc.audioEngine.stopAll();
cc.game.restart();
}
};
t.prototype.retry = function() {
if (!this.updating && this.canRetry) {
this.canRetry = !1;
this.am.downloadFailedAssets();
}
};
t.prototype.clearCache = function() {
var e = this.stroagePath;
if (!e) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(e)) {
throw new Error("path:--\x3e" + e + "not exist");
}
jsb.fileUtils.removeDirectory(e);
};
t.prototype.destroy = function() {
if (this.updateListener) {
this.am.setEventCallback(null);
this.updateListener = null;
}
};
t._instance = null;
t.EventType = cc.sys.isNative && ((n = {})[jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST] = "ERROR_NO_LOCAL_MANIFEST", 
n[jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST] = "ERROR_DOWNLOAD_MANIFEST", n[jsb.EventAssetsManager.ERROR_PARSE_MANIFEST] = "ERROR_PARSE_MANIFEST", 
n[jsb.EventAssetsManager.ALREADY_UP_TO_DATE] = "ALREADY_UP_TO_DATE", n[jsb.EventAssetsManager.NEW_VERSION_FOUND] = "NEW_VERSION_FOUND", 
n[jsb.EventAssetsManager.UPDATE_PROGRESSION] = "UPDATE_PROGRESSION", n[jsb.EventAssetsManager.UPDATE_FINISHED] = "UPDATE_FINISHED", 
n[jsb.EventAssetsManager.UPDATE_FAILED] = "UPDATE_FAILED", n[jsb.EventAssetsManager.UPDATE_NEEDRESTART] = "UPDATE_NEEDRESTART", 
n[jsb.EventAssetsManager.ERROR_UPDATING] = "ERROR_UPDATING", n[jsb.EventAssetsManager.ERROR_DECOMPRESS] = "ERROR_DECOMPRESS", 
n);
return t;
}(cc.EventTarget);
o.default = a;
cc._RF.pop();
}, {} ],
HttpUtils: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "31b48Sg97lMyKL1udrzhkoj", "HttpUtils");
var n = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var s = e("./GameData"), a = e("./HallDataConfig"), i = cc._decorator, c = i.ccclass, r = (i.property, 
function() {
function e() {}
t = e;
e.getInstance = function() {
null == t._instance && (t._instance = new t());
return t._instance;
};
e.prototype.httpGet = function(e, t) {
var o = cc.loader.getXMLHttpRequest();
console.log("url->" + e);
o.onreadystatechange = function() {
console.log("xhrxhrxhrxhrxhr");
console.log(o.readyState);
console.log(o.status);
if (4 === o.readyState && o.status >= 200 && o.status < 300) {
var e = o.responseText;
t(e);
} else t(null);
};
o.open("GET", e, !0);
cc.sys.isNative && o.setRequestHeader("Accept-Encoding", "gzip,deflate");
o.timeout = 5e3;
o.send();
};
e.prototype.getJsonData = function() {
var e = a.default.getInstance().getGameJsonUrl();
console.log("url->" + e);
t.getInstance().httpGet(e, function(e) {
if (e) {
console.log("网络json");
try {
s.default.getInstance().clearData();
for (var t = JSON.parse(e), o = 0; o < t.length; o++) s.default.getInstance().initData(t[o]);
console.log(JSON.stringify(t));
} catch (e) {}
} else ;
});
};
var t;
return e = t = n([ c ], e);
}());
o.default = r;
cc._RF.pop();
}, {
"./GameData": "GameData",
"./HallDataConfig": "HallDataConfig"
} ],
MoveIn_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "8b2e7xNtSlMOKjtgQ7Wutr0", "MoveIn_my");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = a.property, r = cc.Enum({
left: 1,
right: 2,
top: 3,
bottom: 4
}), l = cc.Enum({
Bezier: 1,
JumpTo: 2,
EaseElastic: 3,
Rote: 4
}), d = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.delayTime = 0;
t.direction = r.left;
t.action = l.Bezier;
t.scoreAudio = null;
t.isLoad = !0;
return t;
}
t.prototype.getScreenPos = function(e, t) {
var o, n = cc.Camera.findCamera(e), s = cc.view.getDesignResolutionSize(), a = new cc.Vec2(0, s.height), i = new cc.Vec2(s.width, 0), c = e.position;
e.position;
null != e.parent && (c = e.parent.convertToWorldSpaceAR(c));
if (null != n) {
a = n.getCameraToWorldPoint(a, new cc.Vec2());
i = n.getCameraToWorldPoint(i, new cc.Vec2());
}
switch (t) {
case r.bottom:
o = new cc.Vec2(c.x, i.y - e.getContentSize().height * (1 - e.getAnchorPoint().y));
break;

case r.left:
o = new cc.Vec2(a.x - e.getContentSize().width * (1 - e.getAnchorPoint().x), c.y);
break;

case r.right:
o = new cc.Vec2(i.x + e.getContentSize().width * e.getAnchorPoint().x, c.y);
break;

case r.top:
o = new cc.Vec2(c.x, a.y + e.getContentSize().width * e.getAnchorPoint().y);
}
null != e.parent && (o = e.parent.convertToNodeSpaceAR(o));
return o;
};
t.prototype.onLoad = function() {
this.isLoad || this.doShowAction();
};
t.prototype.doShowAction = function() {
var e = this.node.position, t = this.getScreenPos(this.node, this.direction);
this.node.setPosition(t);
this.node.opacity = 255;
var o;
switch (this.action) {
case l.Bezier:
o = cc.bezierTo(1, [ cc.v2(.5 * e.x, e.y + 150), cc.v2(.5 * e.x, e.y + 150), cc.v2(e.x, e.y) ]);
break;

case l.EaseElastic:
o = cc.moveTo(1, e).easing(cc.easeElasticOut(2));
break;

case l.JumpTo:
o = cc.jumpTo(1, e, 200, 1);
break;

case l.Rote:
var n = -10;
this.direction == r.left && (n = 10);
o = cc.spawn(cc.moveTo(1, e).easing(cc.easeBackOut()), cc.rotateBy(.58, n), cc.rotateBy(.58, -n).easing(cc.easeBackInOut()));
break;

default:
o = cc.moveTo(1, e).easing(cc.easeElasticOut(2));
}
var s, a = this;
s = cc.callFunc(function() {
a.actionCallBack && a.actionCallBack();
}, this);
var i = cc.delayTime(this.delayTime), c = cc.sequence(i, cc.callFunc(function() {
a.scoreAudio && cc.audioEngine.play(a.scoreAudio, !1, 1);
}), o, s);
this.node.runAction(c);
};
t.prototype.start = function() {
this.isLoad && this.doShowAction();
console.log("movein start");
};
s([ c ], t.prototype, "delayTime", void 0);
s([ c({
type: r
}) ], t.prototype, "direction", void 0);
s([ c({
type: l
}) ], t.prototype, "action", void 0);
s([ c(cc.AudioClip) ], t.prototype, "scoreAudio", void 0);
s([ c() ], t.prototype, "isLoad", void 0);
return t = s([ i ], t);
}(cc.Component);
o.default = d;
cc._RF.pop();
}, {} ],
NodeComp_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "c0231xHxy5I37x23X5C20zz", "NodeComp_my");
var n = cc.Class({
extends: cc.Component,
editor: !1,
properties: {},
start: function() {
this.enabled = !1;
}
});
t.exports = n;
cc._RF.pop();
}, {} ],
RewardManagerHall: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "41f8eLjTDBOsaRgil5H1pOe", "RewardManagerHall");
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./AdsManagerHall"), s = function() {
function e() {
this.showCrossCount = 0;
this.mapRewardItems = new Map();
this.jsonPath = "content.json";
this.showCrossCount = 0;
}
e.getInstance = function() {
null == e._instance && (e._instance = new e());
return e._instance;
};
e.prototype.loadConfig = function() {
var e = this;
cc.loader.loadRes(this.jsonPath, function(t, o) {
t ? cc.log("解析json文件失败" + t) : o.json.forEach(function(t) {
var o = t.Indexs.split(",");
if (0 != o.length) {
console.log(o);
for (var n = t.IAPID, s = t.ModuleName, i = t.Key, c = 0; c < o.length; c++) {
var r = new a(n, s, i, -1), l = o[c];
r.index = Number(l);
e.mapRewardItems.set(r.getKey(), r);
}
console.log(e.mapRewardItems);
}
});
});
};
e.prototype.getRewardInfoItem = function(e, t, o) {
var n = this.getItemKey(e, t, o);
return this.mapRewardItems.has(n) ? this.mapRewardItems.get(n) : null;
};
e.prototype.getItemKey = function(e, t, o) {
console.log(e + t + String(o));
return e + t + String(o);
};
e.prototype.isLocked = function(e) {
if (!this.mapRewardItems.has(e)) return !1;
var t = cc.sys.localStorage.getItem(e);
t || (t = 1);
cc.sys.localStorage.setItem(e, t);
return 1 == t;
};
e.prototype.isLockOther = function(e) {
var t = cc.sys.localStorage.getItem(e);
t || (t = 1);
cc.sys.localStorage.setItem(e, t);
return 1 == t;
};
e.prototype.showRewardAds = function(e) {
if (this.mapRewardItems.has(e) && this.isLocked(e)) {
console.log("显示reward,开始解锁" + e);
this.showRewardAdsByItem(this.mapRewardItems.get(e));
}
};
e.prototype.showRewardAdsByItem = function(e) {
if (jsToCPP.getInstance().checkNetworkAvailable()) {
cc.sys.isMobile && this.initLisenter();
if (n.default.getInstance().showReward()) {
this.s_showFullAds = !1;
this._waitingUnLockItemInfo = e;
this.showRewardLoadingCall && this.showRewardLoadingCall();
} else {
n.default.getInstance().preAdsByType(n.ADS_TYPE.kTypeRewardedAds);
if (!this.showRewardFailedHandleAndroid()) return;
console.log(e);
this._waitingUnLockItemInfo = e;
this.unLockedByItem(this._waitingUnLockItemInfo);
}
cc.log("要解锁的key", this._waitingUnLockItemInfo.getKey());
cc.log("=========onAdsCollapsed %d 1111=========", this.s_showFullAds);
} else {
jsToCPP.getInstance().popAlertDialog("there is problem with internet connection and try later");
this.showRewardFalseCall && this.showRewardFalseCall();
}
};
e.prototype.unLocked = function(e) {
cc.sys.localStorage.setItem(e, 0);
console.log("解锁成功" + e);
};
e.prototype.unLockedByItem = function(e) {
console.log("解锁" + e.getKey());
this.unLocked(e.getKey());
};
e.prototype.showRewardFailedHandleAndroid = function() {
var e, t = n.ADS_TYPE.kTypeInterstitialAds;
if (this.showCrossCount >= 2) {
this.showCrossCount = 0;
t = n.ADS_TYPE.kTypeCrosspromoAds;
}
this.showCrossCount++;
if (!(e = t == n.ADS_TYPE.kTypeInterstitialAds ? n.default.getInstance().showInterstitial() : n.default.getInstance().showCross())) {
jsToCPP.getInstance().popAlertDialog("there is problem with internet connection and try later");
this.showRewardFalseCall && this.showRewardFalseCall();
}
return e;
};
e.prototype.unLisenter = function() {
n.default.getInstance().onAdsLoaded = null;
n.default.getInstance().onAdsClicked = null;
n.default.getInstance().onAdsExpanded = null;
n.default.getInstance().onAdsCollapsed = null;
n.default.getInstance().onAdsLoadFailed = null;
n.default.getInstance().onAdsRewarded = null;
};
e.prototype.initLisenter = function() {
console.log(" RewardManagerHall initLisenter");
var e = this;
n.default.getInstance().initLisenter();
n.default.getInstance().onAdsLoaded = function(e) {};
n.default.getInstance().onAdsClicked = function(e) {};
n.default.getInstance().onAdsExpanded = function(e) {
console.log(" RewardManagerHall====>广告====>ID值" + e);
};
n.default.getInstance().onAdsCollapsed = function(t) {
console.log(" RewardManagerHall====>onAdsCollapsed====>ID值" + t);
e.unLisenter();
console.log(" RewardManagerHall====>self.unLisenter()");
e.removeRewardLoadingCall && e.removeRewardLoadingCall(e._waitingUnLockItemInfo.getKey());
};
n.default.getInstance().onAdsLoadFailed = function(t, o) {
console.log(" RewardManagerHall====>onAdsLoadFailed====>ID值" + o);
e.unLisenter();
console.log(" RewardManagerHall====>self.unLisenter()");
o != n.ADS_TYPE.kTypeInterstitialAds || e.removeRewardLoadingCall && e.removeRewardLoadingCall(e._waitingUnLockItemInfo.getKey());
};
n.default.getInstance().onAdsRewarded = function(t, o, n) {
console.log(" RewardManagerHall====>self.unLisenter()");
e.unLisenter();
console.log(" RewardManagerHall====>onAdsRewarded-------" + e._waitingUnLockItemInfo.getKey());
if (n) e.removeRewardLoadingCall && e.removeRewardLoadingCall(e._waitingUnLockItemInfo.getKey()); else {
e.unLockedByItem(e._waitingUnLockItemInfo);
e.removeRewardLoadingCall && e.removeRewardLoadingCall(e._waitingUnLockItemInfo.getKey());
}
};
};
return e;
}();
o.default = s;
var a = function() {
function e(e, t, o, n) {
this.index = 999;
this.iapId = e;
this.moduleName = t;
this.keyInModule = o;
this.index = n;
}
e.prototype.getKey = function() {
return this.moduleName + this.keyInModule + this.index;
};
e.prototype.isNull = function() {
return 999 == this.index;
};
return e;
}();
o.RewardInfoItem = a;
cc._RF.pop();
}, {
"./AdsManagerHall": "AdsManagerHall"
} ],
ScaleRootAdapter_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "5b907LT8xVL4rzP91xpCYh2", "ScaleRootAdapter_my");
cc.Class({
extends: cc.Component,
properties: {},
setUp: function() {
var e = cc.view.getFrameSize(), t = cc.Canvas.instance.designResolution, o = e.width / t.width, n = e.height / t.height, s = 1;
o > n ? s = n / o : n > o && (s = o / n);
this.node.scaleX = s;
this.node.scaleY = s;
},
start: function() {
this.setUp();
},
lateUpdate: function() {
0;
}
});
cc._RF.pop();
}, {} ],
SubgameManager: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "44f6dY6fyFJEKYfngsy9mzU", "SubgameManager");
var n = {
_storagePath: [],
_getfiles: function(e, t, o, n) {
this._storagePath[e] = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + window.platformInstance.getLocalAppName() + e;
this._downloadCallback = o;
this._finishCallback = n;
this._fileName = e;
var s = window.platformInstance.getDownUrl() + e;
this.check_before(e);
var a = this._storagePath[e] + "/project.manifest";
this.manifestUrl = a;
var i = JSON.stringify({
packageUrl: s,
remoteManifestUrl: s + "/project.manifest",
remoteVersionUrl: s + "/version.manifest",
version: "0.8",
assets: {},
searchPaths: []
});
this._am = new jsb.AssetsManager("", this._storagePath[e], function(e, t) {
console.log("vA---\x3e" + JSON.stringify(o));
console.log("vB---\x3e" + JSON.stringify(o));
for (var o = e.split("."), n = t.split("."), s = 0; s < o.length; ++s) {
var a = parseInt(o[s]), i = parseInt(n[s] || 0);
if (a !== i) return a - i;
}
return n.length > o.length ? -1 : 0;
});
this._am.setVerifyCallback(function(e, t) {
t.compressed;
return !0;
});
cc.sys.os === cc.sys.OS_ANDROID && this._am.setMaxConcurrentTask(2);
1 === t ? this._am.setEventCallback(this._updateCb.bind(this)) : 2 == t ? this._am.setEventCallback(this._checkCb.bind(this)) : this._am.setEventCallback(this._needUpdate.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
console.log(i);
if (jsb.fileUtils.isFileExist(a)) {
console.log("加载本地Manifest");
this._am.loadLocalManifest(this.manifestUrl);
} else {
console.log("加载网络Manifest");
var c = new jsb.Manifest(i, this._storagePath);
this._am.loadLocalManifest(c, this._storagePath);
}
}
console.log("----------");
console.log(JSON.stringify(this.manifestUrl));
console.log(JSON.stringify(this._am.getLocalManifest()));
cc.loader.loadRes(this.manifestUrl, function(e, t) {
e ? cc.log("解析json文件失败" + e) : console.log(JSON.stringify(t));
});
var r = jsb.fileUtils.getSearchPaths();
console.log(JSON.stringify(r));
console.log("----------");
if (1 === t) {
this._am.update();
this._failCount = 0;
} else this._am.checkUpdate();
this._updating = !0;
console.log("更新文件:" + a);
},
check_before: function(e) {
var t = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + window.platformInstance.getLocalAppName() + e + "/project.manifest.temp";
if (jsb.fileUtils.isFileExist(t)) {
var o = jsb.fileUtils.getStringFromFile(t);
"" == o && (o = "{}");
JSON.parse(o).module != this.file_module && console.log("remove temp file:" + jsb.fileUtils.removeFile(t));
}
},
_updateCb: function(e) {
var t = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("updateCb本地没有配置文件");
t = !0;
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
console.log("updateCb下载配置文件错误");
t = !0;
break;

case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("updateCb解析文件错误");
t = !0;
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
console.log("updateCb发现新的更新");
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("updateCb已经是最新的");
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
this._downloadCallback && this._downloadCallback(e.getPercent());
break;

case jsb.EventAssetsManager.ASSET_UPDATED:
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
console.log("updateCb更新错误");
console.log("错误信息. " + e.getAssetId() + ", " + e.getMessage() + ", " + e.getCURLMCode());
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
var o = jsb.fileUtils.getSearchPaths(), n = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift(o, n);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(o));
jsb.fileUtils.setSearchPaths(o);
this._finishCallback && this._finishCallback(!0);
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this._failCount++;
if (this._failCount <= 3) {
this._am.downloadFailedAssets();
console.log("Update failed. " + e.getAssetId() + ", " + e.getMessage() + ", " + e.getCURLMCode());
console.log("updateCb更新失败" + this._failCount + " 次");
} else {
console.log("updateCb失败次数过多");
this._failCount = 0;
t = !0;
this._updating = !1;
}
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
console.log("updateCb解压失败");
}
if (t) {
cc.eventManager.removeListener(this._updateListener);
this._updating = !1;
this._finishCallback && this._finishCallback(!1);
}
},
stopDown: function() {
self._updating = !1;
this._am.setEventCallback(null);
},
_checkCb: function(e) {
var t = !1;
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
console.log("checkCb本地没有配置文件");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
console.log("checkCb下载配置文件错误");
t = !0;
break;

case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
console.log("checkCb解析文件错误");
t = !0;
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this._getfiles(this._fileName, 1, this._downloadCallback, this._finishCallback);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("checkCb已经是最新的");
this._finishCallback && this._finishCallback(!0);
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
case jsb.EventAssetsManager.ASSET_UPDATED:
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
console.log("checkCb更新错误");
t = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
console.log("checkCb更新完成");
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
console.log("checkCb更新失败");
t = !0;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
console.log("checkCb解压失败");
}
this._updating = !1;
t && this._finishCallback && this._finishCallback(!1);
},
_needUpdate: function(e) {
switch (e.getEventCode()) {
case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
console.log("子游戏已经是最新的，不需要更新");
this._finishCallback && this._finishCallback(!1);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
console.log("子游戏需要更新");
this._finishCallback && this._finishCallback(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
case jsb.EventAssetsManager.ERROR_UPDATING:
case jsb.EventAssetsManager.UPDATE_FAILED:
this._downloadCallback();
}
},
downloadSubgame: function(e, t, o) {
this._getfiles(e, 2, t, o);
},
enterSubgame: function(e) {
if (this._storagePath[e]) {
console.log("enterSubgame: require " + this._storagePath[e] + "/src/main.js");
window.require(this._storagePath[e] + "/src/main.js");
} else this.downloadSubgame(e);
},
isSubgameDownLoad: function(e) {
var t = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + window.platformInstance.getLocalAppName() + e + "/project.manifest";
console.log(t);
return !!jsb.fileUtils.isFileExist(t);
},
needUpdateSubgame: function(e, t, o) {
this._getfiles(e, 3, o, t);
},
setManifest: function(e) {
this._manifestUrl = e;
},
setLogLabel: function(e) {
this._label = e;
}
};
t.exports = n;
cc._RF.pop();
}, {} ],
TransitionScene_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "f0cbbe7smJKtL0Vt4L7hVyT", "TransitionScene_my");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = e("./CocosHelper_my"), i = cc._decorator, c = i.ccclass, r = (i.property, 
function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.newSceneName = null;
return t;
}
o = t;
t.changeScene = function(e, t) {
void 0 === t && (t = "codebase/TransitionScen");
cc.director.loadScene(e);
};
t.prototype.startChange = function() {
var e = this;
a.CocosHelper.visitNode(cc.director.getScene(), function(e) {
for (var t = 0, o = e.getComponents(cc.Component); t < o.length; t++) {
var n = o[t], s = n.transitiOnExit;
void 0 != s && s instanceof Function && s.bind(n)();
}
});
this.node.opacity = 0;
this.node.stopAllActions();
var t = cc.callFunc(function() {
null != e.newSceneName && cc.director.preloadScene(e.newSceneName, function() {
cc.director.loadScene(e.newSceneName, function() {
a.CocosHelper.visitNode(cc.director.getScene(), function(e) {
for (var t = 0, o = e.getComponents(cc.Component); t < o.length; t++) {
var n = o[t], s = n.transitionOnEnter;
void 0 != s && s instanceof Function && (n.hasTransition = !0);
}
});
var e = cc.find("TransitionSceneNode");
if (null != e) {
var t = cc.callFunc(function() {
cc.game.removePersistRootNode(this);
this.destroy();
a.CocosHelper.visitNode(cc.director.getScene(), function(e) {
for (var t = 0, o = e.getComponents(cc.Component); t < o.length; t++) {
var n = o[t], s = n.transitionOnEnter;
void 0 != s && s instanceof Function && s.bind(n)();
}
});
}, e);
e.runAction(cc.sequence(cc.fadeOut(.6), t));
}
});
e.newSceneName = null;
});
}, this);
this.node.runAction(cc.sequence(cc.fadeIn(.6), t));
};
t.prototype.onDestroy = function() {
o.currentChangeName = "";
};
t.prototype.start = function() {
"" != o.currentChangeName && cc.error("scene:" + o.currentChangeName + " isChanging, don`t change " + this.newSceneName);
o.currentChangeName = this.newSceneName;
this.startChange();
};
var o;
t.currentChangeName = "";
return t = o = s([ c ], t);
}(cc.Component));
o.default = r;
cc._RF.pop();
}, {
"./CocosHelper_my": "CocosHelper_my"
} ],
VersionMG: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "bcb1dXxOSlPtLiu6mkoYazJ", "VersionMG");
var n = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var s = e("./HttpUtils"), a = e("./HallDataConfig"), i = cc._decorator, c = i.ccclass, r = (i.property, 
function() {
function e() {
this.startVersionNum = "versionLocal";
this.showPopSceneName = "cakeChoose";
this.startVersion = 10;
this.androidV = 11;
this.iosV = 11;
this.isShowPop = !1;
cc.sys.platform == cc.sys.ANDROID ? this.startVersion = this.androidV : this.startVersion = this.iosV;
cc.sys.localStorage.setItem(this.startVersionNum, this.startVersion);
}
t = e;
e.getInstance = function() {
null == t._instance && (t._instance = new t());
return t._instance;
};
e.prototype.initVersion = function() {
var e = cc.sys.localStorage.getItem(this.startVersionNum);
e || (e = this.startVersion);
cc.sys.localStorage.setItem(this.startVersionNum, this.startVersion);
};
e.prototype.getVersion = function() {
var e = cc.sys.localStorage.getItem(this.startVersionNum);
e || (e = this.startVersion);
return e;
};
e.prototype.calIsToPopVerDialog = function() {
var e = a.default.getInstance().getVersionJsonUrl(), t = this;
s.default.getInstance().httpGet(e, function(e) {
if (e) {
console.log("网络json");
try {
var o = JSON.parse(e)[0];
if (o) {
var n = 0, s = "android";
if (cc.sys.platform == cc.sys.ANDROID) {
n = Number(o.androidVersion);
s = "android";
} else {
n = Number(o.iosVersion);
s = "ios";
}
var a = t.getVersion(), i = cc.director.getScene().name;
console.log("平台 ： " + s);
console.log("本地版本" + a);
console.log("网络版本" + n);
console.log("当前场景名" + i);
console.log("是否弹过 " + t.isShowPop);
var c = -1, r = (l = jsToCPP.getInstance()).getArray();
c = Number(r.length);
console.log("是否弹过 " + (0 == c));
if (0 == c && n > t.getVersion() && i == t.showPopSceneName) {
console.log("显示弹框");
t.showPopDialogToMarket();
t.isShowPop = !0;
var l;
(l = jsToCPP.getInstance()).setArray("ont");
l.setArray("two");
l.setArray("three");
}
}
} catch (e) {
console.log("网络json错误 加载本地json");
}
} else ;
});
};
e.prototype.showPopDialogToMarket = function() {};
var t;
return e = t = n([ c ], e);
}());
o.default = r;
cc._RF.pop();
}, {
"./HallDataConfig": "HallDataConfig",
"./HttpUtils": "HttpUtils"
} ],
ViewSizeAdapter_my: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "b1f8aIugDRAkJxwcKb0maG+", "ViewSizeAdapter_my");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = (a.property, a.disallowMultiple), r = a.menu, l = function(e) {
n(t, e);
function t() {
return null !== e && e.apply(this, arguments) || this;
}
t.prototype.setup = function() {
var e = cc.view.getFrameSize();
cc.log(" fx == " + e.width + " fy ==" + e.height);
var t, o = cc.Canvas.instance.designResolution, n = e.width / o.width, s = e.height / o.height;
t = n > s ? s : n;
cc.log("scaleX == " + n + " y ==" + s);
cc.log(" minScale == " + t);
cc.log(" Rx == " + e.width / t + " Ry ==" + e.height / t);
cc.view.setDesignResolutionSize(e.width / t, e.height / t, cc.ResolutionPolicy.NO_BORDER);
cc.Canvas.instance.alignWithScreen();
};
t.prototype.onLoad = function() {
var e = this;
this.setup();
cc.view.setResizeCallback(function() {
e.setup();
cc.director.dispatchEvent(new cc.Event.EventCustom("ResizeFrame", !0));
});
};
return t = s([ i, c(), r("common/viewadapter/ViewSizeAdapter") ], t);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ],
gameItem: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "1c9c8AhbOtFyKoYlOIAPtpu", "gameItem");
var n = this && this.__extends || function() {
var e = function(t, o) {
return (e = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
})(t, o);
};
return function(t, o) {
e(t, o);
function n() {
this.constructor = t;
}
t.prototype = null === o ? Object.create(o) : (n.prototype = o.prototype, new n());
};
}(), s = this && this.__decorate || function(e, t, o, n) {
var s, a = arguments.length, i = a < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, o) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(e, t, o, n); else for (var c = e.length - 1; c >= 0; c--) (s = e[c]) && (i = (a < 3 ? s(i) : a > 3 ? s(t, o, i) : s(t, o)) || i);
return a > 3 && i && Object.defineProperty(t, o, i), i;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var a = cc._decorator, i = a.ccclass, c = a.property, r = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.moveAudio = null;
t.isTouch = !1;
t.canTouch = !1;
return t;
}
t.prototype.touchButton = function() {
if (!this.canTouch) {
this.canTouch = !0;
console.log(this.node.name);
var e = this;
if (this.isTouch) {
this.node.height = 120;
this.node.getChildByName("content").height = 120;
this.node.getChildByName("content").height = 120;
this.node.getChildByName("box").height = 123;
this.node.getChildByName("icon").position = cc.v2(-150, -20);
e.canTouch = !1;
this.isTouch = !1;
this.canTouch = !1;
} else {
this.isTouch = !0;
this.node.getChildByName("content").height;
var t = this.node.getChildByName("icon"), o = t.position;
this.node.getChildByName("content").runAction(cc.repeatForever(cc.sequence(cc.delayTime(.001), cc.callFunc(function() {
e.node.getChildByName("content").height = e.node.getChildByName("content").height + 20;
e.node.getChildByName("box").height = e.node.getChildByName("box").height + 20;
e.node.height = e.node.height + 20;
o = o.add(cc.v2(0, 11.2));
t.setPosition(o);
console.log(t.position.y);
if (e.node.getChildByName("content").height >= 400) {
e.node.getChildByName("content").stopAllActions();
e.node.height = 400;
e.node.getChildByName("content").height = 400;
e.node.getChildByName("box").height = 403;
e.canTouch = !1;
}
}))));
}
}
};
t.prototype.start = function() {};
s([ c(cc.AudioClip) ], t.prototype, "moveAudio", void 0);
return t = s([ i ], t);
}(cc.Component);
o.default = r;
cc._RF.pop();
}, {} ],
showLaodingHall: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "7d60bbItY5MvoLjz/MHU9so", "showLaodingHall");
Object.defineProperty(o, "__esModule", {
value: !0
});
var n = e("./AdsManagerHall"), s = function() {
function e() {
this._loadingMinTime = 2;
this._loadingMaxTime = 5;
this._adLoadType = n.ADS_TYPE.kTypeInterstitialAds;
this._adShowing = !1;
this._isRequestingLoadAd = !1;
this._bLoadingCanRemove = !1;
this._adLoadDone = !1;
if (cc.sys.isMobile) {
this.initAdsCall();
n.default.getInstance().initLisenter();
}
}
e.getInstance = function() {
null == e._instance && (e._instance = new e());
return e._instance;
};
e.prototype.initAdsCall = function() {
var e = this;
n.default.getInstance().onAdsLoaded = function(t) {
console.log(" showLaodingHall====>广告====>ID值" + t);
e._isRequestingLoadAd && e._adLoadType == t && (t == n.ADS_TYPE.kTypeInterstitialAds ? n.default.getInstance().showInterstitial() : n.default.getInstance().showCross());
};
n.default.getInstance().onAdsClicked = function(e) {};
n.default.getInstance().onAdsExpanded = function(t) {
console.log(" showLaodingHall====>广告====>ID值" + t);
if (e._adLoadType == t) {
e.isAdsShowed = !0;
e._adLoadDone = !0;
e._adShowing = !0;
}
};
n.default.getInstance().onAdsCollapsed = function(t) {
console.log(" showLaodingHall====>广告====>ID值" + t);
console.log(t);
if (e._adLoadType == t) {
if (e._bLoadingCanRemove) {
e._taskDone();
return;
}
e._adShowing = !1;
}
e._timeCheckSchedule(0);
};
n.default.getInstance().onAdsLoadFailed = function(t, o) {
e._adLoadType == o && (e._adLoadDone = !0);
};
};
e.prototype.showAds = function(e) {
var t = cc.find("Canvas"), o = new cc.Node();
console.log("add prefab1111");
t.addChild(o);
o.name = "newMyPrefab";
o.setPosition(0, 0);
o.zIndex = 100;
n.default.getInstance().initLisenter();
this.loadAd(e);
this._timeEnter = new Date();
};
e.prototype.loadAd = function(e) {
void 0 === e && (e = !1);
this._isRequestingLoadAd = !1;
this._adShowing = !1;
this._bLoadingCanRemove = !1;
this._adLoadDone = !1;
this._adLoadType = e ? n.ADS_TYPE.kTypeCrosspromoAds : n.ADS_TYPE.kTypeInterstitialAds;
var t = cc.find("Canvas"), o = this, s = cc.sequence(cc.delayTime(1.5), cc.callFunc(function() {
o.isAdsShowed = !1;
cc.sys.isMobile && (o._adLoadType == n.ADS_TYPE.kTypeInterstitialAds ? n.default.getInstance().showInterstitial() : n.default.getInstance().showCross());
o.scheduTime = setInterval(function() {
o._timeCheckSchedule(0);
}, 5);
}));
t.runAction(s);
};
e.prototype._timeCheckSchedule = function(e) {
var t = (new Date().getTime() - this._timeEnter.getTime()) % 864e5 % 36e5 % 6e4, o = Math.round(t / 1e3);
if (o >= this._loadingMinTime && this._adLoadDone) this._adLoadInTime(); else if (o >= this._loadingMaxTime) if (this._adLoadType != n.ADS_TYPE.kTypeCrosspromoAds || this.isAdsShowed) this._adLoadTimeOut(); else {
this._isRequestingLoadAd = !1;
this._adLoadType = n.ADS_TYPE.kTypeInterstitialAds;
cc.sys.isMobile && n.default.getInstance().showInterstitial();
}
};
e.prototype._adLoadInTime = function() {
this._adShowing ? this._bLoadingCanRemove = !0 : this._taskDone();
};
e.prototype._adLoadTimeOut = function() {
this._adShowing ? this._bLoadingCanRemove = !0 : this._taskDone();
};
e.prototype._taskDone = function() {
clearInterval(this.scheduTime);
var e = cc.find("Canvas");
e.getChildByName("newMyPrefab") && e.getChildByName("newMyPrefab").removeFromParent();
this.loadingDoneCallback && this.loadingDoneCallback();
console.log("hide ads");
};
return e;
}();
o.default = s;
cc._RF.pop();
}, {
"./AdsManagerHall": "AdsManagerHall"
} ]
}, {}, [ "Helloworld", "ButtonSafe_hall", "MoveIn_my", "AdsManagerHall", "RewardManagerHall", "showLaodingHall", "GameData", "HallDataConfig", "HotUpdate", "HotUpdatePanel", "HttpUtils", "SubgameManager", "VersionMG", "ClickScale_my", "CocosHelper_my", "ColorRectAssembler_my", "ColorRect_my", "NodeComp_my", "TransitionScene_my", "BgScale_my", "ScaleRootAdapter_my", "ViewSizeAdapter_my", "gameItem" ]);